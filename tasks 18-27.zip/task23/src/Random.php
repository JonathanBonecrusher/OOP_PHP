<?php

namespace App;

class Random
{
    public const RAND_MAX = 32767;
    public const RAND = 6849;
    public const RAND2 = 13456;
    public const  RAND3 = 17813;
    private $seed;
    public $next;

    public function __construct($seed)
    {
        $this->seed = $seed;
        $this->next = $seed;
    }

    public function getSeed()
    {
        return $this->seed;
    }

    public function getNext()
    {
        $this->next = $this->next * self::RAND_MAX + self::RAND2;
        return ($this->next / self::RAND3) % (self::RAND_MAX + 1);
    }

    public function reset()
    {
        $this->next = $this->seed;
    }
}