<?php

namespace App;
use App\Square;

class SquaresGenerator
{
    private $side;
    private $amount;

    public function __construct($side)
    {
        $this->side = $side;
    }

    public static function generate($side, $amount)
    {
        $filled = array_fill(0, $amount, new Square($side));
        return $filled;
    }
}