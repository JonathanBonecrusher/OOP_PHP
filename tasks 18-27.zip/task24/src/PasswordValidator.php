<?php

namespace App;

class PasswordValidator
{
    private $array;

    public function __construct($newDefaultOptions = [], $defaultOptions = [
            'containNumbers' => false,
            'minLength' => 8
        ])
    {
        $this->array = array_replace($defaultOptions, $newDefaultOptions);
    }

    public function validate($password)
    {
        $errors = [];
        if (strlen($password) < $this->array['minLength']) {
            $errors['minLength'] = 'too small';
        }
        if ($this->array['containNumbers']) {
            if (!$this->hasNumber($password)) {
                $errors['containNumbers'] = 'should contain at least one number';
            }
        }

        return $errors;
    }
    private function hasNumber($subject)
    {
        return strpbrk($subject, '1234567890') !== false;
    }
}