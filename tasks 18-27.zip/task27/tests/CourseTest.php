<?php
// установка
// composer require --dev phpunit/phpunit ^10
// composer update
// запуск
// php ./vendor/bin/phpunit --testdox tests
namespace App\Tests;

use App\Course;
use PHPUnit\Framework\TestCase;

class CourseTest extends TestCase{
    public function testCourse(){
        $name="name";
        $course = new Course($name);
        $this->assertEquals($name, $course->getName());
    }
}