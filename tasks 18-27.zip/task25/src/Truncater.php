<?php

namespace App;

class Truncater
{
    const OPTIONS = [
        'separator' => '...',
        'length' => 200,
    ];
    
    private $options = [];

    public function __construct($options = [])
    {
        $this->options = array_merge(self::OPTIONS, $options);
    }
    public function truncate($string, $callOptions = [])
    {
        $newOptions = array_merge($this->options, $callOptions);

        $substr = substr($string, 0, $newOptions['length']);

        if (strlen($substr) < strlen($string)) {
            return "{$substr}{$newOptions['separator']}";
        } else {
            return $substr;
        }
    }
}