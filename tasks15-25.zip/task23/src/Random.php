<?php

namespace App;

class Random
{
    public const RAND_MAX = 32767;
    public const RAND = 1103515245;
    public const RAND2 = 12345;
    public const  RAND3 = 65536;
    private $seed;
    public $next;

    public function __consrtuct($seed)
    {
        $this->seed = $seed;
    }

    public function getSeed()
    {
        var_dump($this->seed);
        return $this->seed;
    }

    public function getNext()
    {
        $this->next = $this->getSeed() * self::RAND_MAX + self::RAND2;
        return ($this->next / self::RAND3) % (self::RAND_MAX + 1);
    }

    public function reset()
    {
        return $this->seed;
    }
}