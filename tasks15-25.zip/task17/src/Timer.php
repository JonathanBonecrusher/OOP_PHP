<?php

namespace App;

class Timer
{
    private $secondsCount;
    public const SEC_PER_MIN = 60;
    public const SEC_PER_HOUR = 3600;

    public function __construct($sec, $min = 0, $hour = 0)
    {
        $this->secondsCount = $sec + self::SEC_PER_MIN * $min + self::SEC_PER_HOUR * $hour;
    }    

    public function getLeftSeconds()
    {
        return $this->secondsCount;
    }

    public function tick()
    {
        $this->secondsCount--;
    }
}