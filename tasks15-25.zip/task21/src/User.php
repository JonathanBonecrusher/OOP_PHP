<?php

namespace App;

class Safe
{
    private $id;
    private $name;
    public function __construct(int $id, string $name)
    {
        $this->id = $id;
        $this->name = $name;        
    }
    public function compareTo($user): bool
    {
        return $this->id === $user->id;
    }
}